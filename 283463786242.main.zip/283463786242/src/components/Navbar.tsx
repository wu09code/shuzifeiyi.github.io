import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Menu, X, Search, Moon, Sun, Heart, User, ChevronDown, ScrollText, Camera, Users, Newspaper } from 'lucide-react';
import { useTheme } from '@/hooks/useTheme';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { theme, toggleTheme } = useTheme();
  
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { 
      label: '首页', 
      path: '/' 
    },
    { 
      label: '非遗项目', 
      path: '#', 
      icon: <ScrollText size={18} />,
      submenu: [
        { label: '辽宁剪纸', path: '/heritage/1' },
        { label: '辽西皮影戏', path: '/heritage/2' },
        { label: '满族刺绣', path: '/heritage/3' }
      ]
    },
    { 
      label: '互动体验', 
      path: '/experience', 
      icon: <Camera size={18} />
    },
    { 
      label: '文化传播', 
      path: '#', 
      icon: <Newspaper size={18} />,
      submenu: [
        { label: '传承人风采', path: '/artist/1' },
        { label: '新闻动态', path: '/news/1' }
      ]
    }
  ];

  return (
    <motion.nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/90 dark:bg-gray-900/90 backdrop-blur-md shadow-md' : 'bg-transparent'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-red-700 flex items-center justify-center mr-3">
              <i className="fa-solid fa-scissors text-white text-xl"></i>
            </div>
            <span className="text-2xl font-bold text-gray-800 dark:text-white">辽宁非遗</span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {menuItems.map((item, index) => (
              <div key={index} className="relative group">
                <Link 
                  to={item.path}
                  className={`flex items-center text-gray-700 dark:text-gray-300 hover:text-red-700 dark:hover:text-red-500 font-medium transition-colors ${
                    item.submenu ? 'cursor-pointer' : ''
                  }`}
                >
                  {item.icon && <span className="mr-2">{item.icon}</span>}
                  {item.label}
                  {item.submenu && <ChevronDown size={16} className="ml-1 transition-transform group-hover:rotate-180" />}
                </Link>
                
                {/* Submenu */}
                {item.submenu && (
                  <div className="absolute left-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform origin-top scale-95 group-hover:scale-100 z-50">
                    {item.submenu.map((subitem, subindex) => (
                      <Link 
                        key={subindex} 
                        to={subitem.path} 
                        className="block px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-red-50 dark:hover:bg-gray-700 hover:text-red-700 dark:hover:text-red-500 transition-colors"
                      >
                        {subitem.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
          
          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleTheme} 
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300"
            >
              {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>
            <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300 hidden sm:block">
              <Search size={20} />
            </button>
            <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300 hidden sm:block">
              <Heart size={20} />
            </button>
            <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300 hidden sm:block">
              <User size={20} />
            </button>
            
            {/* Mobile menu button */}
            <button 
              className="md:hidden p-2 rounded-lg bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 shadow-md"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {isOpen && (
        <motion.div 
          className="md:hidden bg-white dark:bg-gray-900 shadow-lg"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="container mx-auto px-4 py-4 space-y-4">
            {menuItems.map((item, index) => (
              <div key={index}>
                <Link 
                  to={item.path}
                  className="flex items-center text-gray-700 dark:text-gray-300 hover:text-red-700 dark:hover:text-red-500 font-medium py-2 border-b border-gray-100 dark:border-gray-800"
                  onClick={() => setIsOpen(false)}
                >
                  {item.icon && <span className="mr-3">{item.icon}</span>}
                  {item.label}
                </Link>
                
                {/* Mobile submenu */}
                {item.submenu && (
                  <div className="ml-10 mt-2 space-y-2">
                    {item.submenu.map((subitem, subindex) => (
                      <Link 
                        key={subindex} 
                        to={subitem.path} 
                        className="block py-2 text-gray-600 dark:text-gray-400 hover:text-red-700 dark:hover:text-red-500 text-sm"
                        onClick={() => setIsOpen(false)}
                      >
                        {subitem.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
};

export default Navbar;