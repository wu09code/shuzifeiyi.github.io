import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin, ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center mb-6">
              <div className="w-10 h-10 rounded-full bg-red-700 flex items-center justify-center mr-3">
                <i className="fa-solid fa-scissors text-white text-xl"></i>
              </div>
              <span className="text-2xl font-bold">辽宁非遗</span>
            </div>
            <p className="text-gray-400 mb-6">
              致力于传承和弘扬辽宁地区丰富的非物质文化遗产，让更多人了解和喜爱传统工艺。
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-700 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-700 transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-700 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-700 transition-colors">
                <Youtube size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">快速链接</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-400 hover:text-white transition-colors">首页</Link>
              </li>
              <li>
                <Link to="#" className="text-gray-400 hover:text-white transition-colors">非遗项目</Link>
              </li>
              <li>
                <Link to="/experience" className="text-gray-400 hover:text-white transition-colors">互动体验</Link>
              </li>
              <li>
                <Link to="#" className="text-gray-400 hover:text-white transition-colors">传承人风采</Link>
              </li>
              <li>
                <Link to="#" className="text-gray-400 hover:text-white transition-colors">新闻动态</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">联系方式</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin size={20} className="text-red-500 mr-3 mt-1 flex-shrink-0" />
                <span className="text-gray-400">辽宁省沈阳市和平区文化路111号</span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="text-red-500 mr-3 flex-shrink-0" />
                <span className="text-gray-400">+86 123 4567 8910</span>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="text-red-500 mr-3 flex-shrink-0" />
                <span className="text-gray-400">contact@liaoningfeiyi.com</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">订阅我们</h3>
            <p className="text-gray-400 mb-4">
              订阅我们的新闻通讯，获取最新的非遗活动和资讯。
            </p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="您的邮箱地址" 
                className="px-4 py-2 bg-gray-800 text-white rounded-l-lg focus:outline-none focus:ring-2 focus:ring-red-600 w-full"
              />
              <button className="bg-red-700 hover:bg-red-800 text-white px-4 py-2 rounded-r-lg transition-colors">
                订阅
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} 辽宁非遗文化传承平台. 保留所有权利.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">隐私政策</a>
              <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">使用条款</a>
              <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">关于我们</a>
            </div>
          </div>
        </div>
      </div>
      
      <button 
        onClick={scrollToTop} 
        className="fixed bottom-6 right-6 w-12 h-12 rounded-full bg-red-700 text-white flex items-center justify-center shadow-lg hover:bg-red-800 transition-all transform hover:scale-110 z-50"
        aria-label="回到顶部"
      >
        <ArrowUp size={20} />
      </button>
    </footer>
  );
};

export default Footer;