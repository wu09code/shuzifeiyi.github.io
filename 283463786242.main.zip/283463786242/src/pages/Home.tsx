import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ScrollText, Camera, Users, Newspaper, ChevronRight, Heart, Eye, Share2 } from 'lucide-react';
import { useTheme } from '@/hooks/useTheme';

// 非遗项目数据
const heritageItems = [
  {
    id: 1,
    title: "辽宁剪纸",
    category: "传统美术",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Traditional%20Chinese%20paper%20cutting%20art%2C%20red%20paper%2C%20intricate%20patterns%2C%20cultural%20heritage&sign=180e1bc3e8b24cee907787478a8e6935",
    description: "辽宁剪纸历史悠久，风格独特，以其精细的刀工和丰富的图案著称。",
    likes: 342,
    views: 2567
  },
  {
    id: 2,
    title: "辽西皮影戏",
    category: "传统戏剧",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Chinese%20shadow%20puppet%20theater%2C%20leather%20puppets%2C%20traditional%20stage%2C%20cultural%20performance&sign=b27251af638972deb5e9010f3de20c30",
    description: "辽西皮影戏是一种古老的民间艺术，集绘画、雕刻、音乐、表演于一体。",
    likes: 289,
    views: 1890
  },
  {
    id: 3,
    title: "满族刺绣",
    category: "传统手工艺",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Manchu%20embroidery%2C%20colorful%20silk%20thread%2C%20traditional%20patterns%2C%20cultural%20heritage&sign=b9a9f7b56e8dbafe4543be3564f01284",
    description: "满族刺绣工艺精湛，色彩艳丽，图案多取材于自然和生活。",
    likes: 215,
    views: 1345
  }
];

// 传承人数据
const artists = [
  {
    id: 1,
    name: "王淑兰",
    specialty: "辽宁剪纸传承人",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Elderly%20Chinese%20woman%2C%20paper%20cutting%20artist%2C%20traditional%20crafts%2C%20smiling&sign=5ba585eb6736c1841953ce281370fc9a",
    introduction: "国家级非物质文化遗产项目代表性传承人，从事剪纸艺术60余年。"
  },
  {
    id: 2,
    name: "张文远",
    specialty: "辽西皮影戏传承人",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Middle-aged%20Chinese%20man%2C%20shadow%20puppet%20master%2C%20traditional%20artist%2C%20holding%20puppets&sign=53b0831ddef6d0af729c48180463ff2a",
    introduction: "省级非物质文化遗产项目代表性传承人，致力于皮影戏的传承与创新。"
  }
];

// 新闻动态数据
const news = [
  {
    id: 1,
    title: "辽宁省举办非遗文化艺术节",
    date: "2025-10-20",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Cultural%20festival%20of%20intangible%20cultural%20heritage%2C%20traditional%20performances%2C%20crowd%20of%20people&sign=e313bac3b6365235ca07378e72c88af8",
    summary: "为期三天的非遗文化艺术节在沈阳举行，展示了辽宁地区丰富的非物质文化遗产资源。"
  },
  {
    id: 2,
    title: "辽宁剪纸走进校园活动启动",
    date: "2025-10-15",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Traditional%20paper%20cutting%20class%20in%20school%2C%20children%20learning%2C%20teacher%20instructing&sign=d3ac1589ae8300e4a37ee63f7bff10a4",
    summary: "为传承和弘扬传统文化，辽宁省启动了非遗进校园活动，让学生近距离感受剪纸艺术的魅力。"
  }
];

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  const [visible, setVisible] = useState(false);
  
  useEffect(() => {
    setVisible(true);
  }, []);

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className={`bg-amber-50 dark:bg-gray-900 transition-colors duration-300`}>
      {/* 英雄区域 */}
      <section className="relative overflow-hidden bg-gradient-to-r from-red-800 to-red-600 text-white">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-repeat" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M50 50L90 10L50 90L10 50z' stroke='%23ffffff' fill='none' stroke-width='2'/%3E%3C/svg%3E")`,
            backgroundSize: '80px 80px'
          }}></div>
        </div>
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-2xl">
            <motion.h1 
              className="text-4xl md:text-6xl font-bold mb-6"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              辽宁非遗文化传承
            </motion.h1>
            <motion.p 
              className="text-xl md:text-2xl mb-8 opacity-90"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              探索辽宁地区丰富的非物质文化遗产，感受传统工艺的独特魅力
            </motion.p>
            <motion.div 
              className="flex flex-wrap gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <Link to="/experience" className="bg-white text-red-800 px-8 py-3 rounded-full font-medium hover:bg-opacity-90 transition-all transform hover:scale-105 shadow-lg">
                体验剪纸生成
              </Link>
              <Link to="#heritage" className="bg-transparent border-2 border-white px-8 py-3 rounded-full font-medium hover:bg-white hover:bg-opacity-10 transition-all">
                探索非遗项目
              </Link>
            </motion.div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-amber-50 dark:from-gray-900 to-transparent"></div>
      </section>

      {/* 主要内容区域 */}
      <div className="container mx-auto px-4 py-16">
        {/* 非遗展示区 */}
        <section id="heritage" className="mb-20">
          <div className="flex items-center justify-between mb-10">
            <motion.div 
              initial="hidden"
              animate={visible ? "visible" : "hidden"}
              variants={fadeIn}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-bold text-gray-800 dark:text-white flex items-center">
                <ScrollText className="mr-3 text-red-700 dark:text-red-500" />
                辽宁非遗项目
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mt-2">探索辽宁地区的非物质文化遗产项目</p>
            </motion.div>
            <Link to="#" className="text-red-700 dark:text-red-500 hover:text-red-800 dark:hover:text-red-400 flex items-center font-medium hidden md:flex">
              查看全部 <ChevronRight size={18} className="ml-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {heritageItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial="hidden"
                animate={visible ? "visible" : "hidden"}
                variants={fadeIn}
                transition={{ duration: 0.5, delay: 0.1 * index }}
                className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
              >
                <div className="relative overflow-hidden h-60">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-full object-cover transition-transform duration-700 hover:scale-110" 
                  />
                  <div className="absolute top-4 left-4 bg-red-700 text-white text-sm px-3 py-1 rounded-full">
                    {item.category}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">{item.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">{item.description}</p>
                  <div className="flex justify-between items-center">
                    <div className="flex space-x-4">
                      <span className="flex items-center text-gray-500 dark:text-gray-400">
                        <Heart size={16} className="mr-1" /> {item.likes}
                      </span>
                      <span className="flex items-center text-gray-500 dark:text-gray-400">
                        <Eye size={16} className="mr-1" /> {item.views}
                      </span>
                    </div>
                    <Link 
                      to={`/heritage/${item.id}`} 
                      className="text-red-700 dark:text-red-500 hover:text-red-800 dark:hover:text-red-400 font-medium flex items-center"
                    >
                      详情 <ChevronRight size={16} className="ml-1" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-8 text-center md:hidden">
            <Link to="#" className="text-red-700 dark:text-red-500 hover:text-red-800 dark:hover:text-red-400 font-medium">
              查看全部非遗项目
            </Link>
          </div>
        </section>

        {/* 交互体验区 */}
        <section className="mb-20 bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 lg:p-12 flex flex-col justify-center">
              <motion.div
                initial="hidden"
                animate={visible ? "visible" : "hidden"}
                variants={fadeIn}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-3xl font-bold text-gray-800 dark:text-white flex items-center mb-6">
                  <Camera className="mr-3 text-red-700 dark:text-red-500" />
                  剪纸生成体验
                </h2>
                <p className="text-gray-600 dark:text-gray-300 mb-8 text-lg">
                  上传一张图片，我们将为您生成独特的剪纸风格作品，体验传统工艺与现代技术的完美融合。
                </p>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="bg-red-100 dark:bg-red-900 rounded-full p-2 mr-4 mt-1">
                      <i className="fa-solid fa-upload text-red-700 dark:text-red-400"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800 dark:text-white">上传图片</h3>
                      <p className="text-gray-600 dark:text-gray-300">选择一张您喜欢的图片上传</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="bg-red-100 dark:bg-red-900 rounded-full p-2 mr-4 mt-1">
                      <i className="fa-solid fa-magic text-red-700 dark:text-red-400"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800 dark:text-white">智能转换</h3>
                      <p className="text-gray-600 dark:text-gray-300">系统自动将图片转换为剪纸风格</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="bg-red-100 dark:bg-red-900 rounded-full p-2 mr-4 mt-1">
                      <i className="fa-solid fa-download text-red-700 dark:text-red-400"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800 dark:text-white">下载保存</h3>
                      <p className="text-gray-600 dark:text-gray-300">保存您的专属剪纸作品</p>
                    </div>
                  </div>
                </div>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.98 }}
                  className="mt-10"
                >
                  <Link 
                    to="/experience" 
                    className="bg-red-700 hover:bg-red-800 dark:bg-red-600 dark:hover:bg-red-700 text-white px-8 py-4 rounded-xl font-medium inline-block shadow-lg hover:shadow-xl transition-all"
                  >
                    立即体验
                  </Link>
                </motion.div>
              </motion.div>
            </div>
            <div className="relative bg-red-50 dark:bg-gray-700 hidden lg:block">
              <div className="absolute inset-0 overflow-hidden">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Traditional%20Chinese%20paper%20cutting%20art%20exhibition%2C%20colorful%20paper%20cuts%2C%20cultural%20heritage%20display&sign=988df93140432eff80663899f4dd19ff" 
                  alt="剪纸艺术" 
                  className="w-full h-full object-cover opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-red-50 to-transparent dark:from-gray-900 dark:to-transparent"></div>
              </div>
              <div className="absolute bottom-8 left-8 right-8 bg-white dark:bg-gray-800 bg-opacity-90 dark:bg-opacity-90 backdrop-blur-sm p-6 rounded-xl shadow-lg">
                <p className="italic text-gray-700 dark:text-gray-300">"剪纸艺术是我们民族文化的瑰宝，通过现代技术让更多人了解和喜爱它，是我们的责任。"</p>
                <p className="mt-3 text-right font-medium text-gray-800 dark:text-white">— 王淑兰，辽宁剪纸传承人</p>
              </div>
            </div>
          </div>
        </section>

        {/* 文化传播区 - 传承人和新闻 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* 传承人介绍 */}
          <section>
            <motion.div 
              initial="hidden"
              animate={visible ? "visible" : "hidden"}
              variants={fadeIn}
              transition={{ duration: 0.5 }}
              className="mb-8"
            >
              <h2 className="text-3xl font-bold text-gray-800 dark:text-white flex items-center">
                <Users className="mr-3 text-red-700 dark:text-red-500" />
                非遗传承人
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mt-2">走进非遗传承人的艺术世界</p>
            </motion.div>
            
            <div className="space-y-6">
              {artists.map((artist, index) => (
                <motion.div
                  key={artist.id}
                  initial="hidden"
                  animate={visible ? "visible" : "hidden"}
                  variants={fadeIn}
                  transition={{ duration: 0.5, delay: 0.1 * index }}
                  className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 flex flex-col sm:flex-row"
                >
                  <div className="w-full sm:w-1/3 h-48 sm:h-auto">
                    <img 
                      src={artist.image} 
                      alt={artist.name} 
                      className="w-full h-full object-cover" 
                    />
                  </div>
                  <div className="p-6 w-full sm:w-2/3">
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white">{artist.name}</h3>
                    <p className="text-red-700 dark:text-red-500 text-sm mb-3">{artist.specialty}</p>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{artist.introduction}</p>
                    <Link 
                      to={`/artist/${artist.id}`} 
                      className="text-red-700 dark:text-red-500 hover:text-red-800 dark:hover:text-red-400 font-medium flex items-center"
                    >
                      了解更多 <ChevronRight size={16} className="ml-1" />
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>

          {/* 新闻动态 */}
          <section>
            <motion.div 
              initial="hidden"
              animate={visible ? "visible" : "hidden"}
              variants={fadeIn}
              transition={{ duration: 0.5 }}
              className="mb-8"
            >
              <h2 className="text-3xl font-bold text-gray-800 dark:text-white flex items-center">
                <Newspaper className="mr-3 text-red-700 dark:text-red-500" />
                非遗新闻动态
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mt-2">了解最新的非遗保护与传承资讯</p>
            </motion.div>
            
            <div className="space-y-6">
              {news.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial="hidden"
                  animate={visible ? "visible" : "hidden"}
                  variants={fadeIn}
                  transition={{ duration: 0.5, delay: 0.1 * index }}
                  className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 flex flex-col sm:flex-row"
                >
                  <div className="w-full sm:w-2/5 h-40 sm:h-auto">
                    <img 
                      src={item.image} 
                      alt={item.title} 
                      className="w-full h-full object-cover" 
                    />
                  </div>
                  <div className="p-6 w-full sm:w-3/5">
                    <span className="text-xs text-gray-500 dark:text-gray-400">{item.date}</span>
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white my-2">{item.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{item.summary}</p>
                    <Link 
                      to={`/news/${item.id}`} 
                      className="text-red-700 dark:text-red-500 hover:text-red-800 dark:hover:text-red-400 font-medium flex items-center"
                    >
                      阅读全文 <ChevronRight size={16} className="ml-1" />
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}