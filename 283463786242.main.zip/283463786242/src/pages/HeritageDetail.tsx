import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Share2, ChevronLeft, Eye, MessageSquare } from 'lucide-react';

// 模拟非遗项目详情数据
const heritageDetails = {
  1: {
    id: 1,
    title: "辽宁剪纸",
    category: "传统美术",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Traditional%20Chinese%20paper%20cutting%20art%2C%20red%20paper%2C%20intricate%20patterns%2C%20cultural%20heritage&sign=180e1bc3e8b24cee907787478a8e6935",
    gallery: [
      "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Chinese%20paper%20cutting%20artwork%20close-up%2C%20red%20paper%2C%20detail&sign=f92779dddb6e758af69cba7725c9ccbb",
      "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Paper%20cutting%20artist%20at%20work%2C%20traditional%20craft&sign=2c110493da560c05ef269219416f00e6",
      "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Display%20of%20paper%20cutting%20artworks%2C%20various%20designs&sign=d6b4911559c106b8f2a7cc55d570dd56"
    ],
    description: "辽宁剪纸是辽宁省传统美术的重要组成部分，历史悠久，风格独特。它以其精细的刀工、丰富的图案和深厚的文化内涵而闻名于世。",
    history: "辽宁剪纸的历史可以追溯到明代，经过数百年的发展，形成了具有鲜明地域特色的艺术风格。在漫长的历史进程中，剪纸不仅是一种民间艺术，更是人们表达情感、祈求幸福的重要方式。",
    characteristics: "辽宁剪纸的主要特点是构图饱满、线条流畅、刀法精细、色彩鲜明。作品题材广泛，包括神话传说、历史故事、自然风光、花鸟鱼虫等，反映了辽宁人民的生活情趣和审美追求。",
    inheritance: "近年来，辽宁省加大了对剪纸艺术的保护和传承力度，通过建立传承基地、举办培训班、组织展览等方式，使这一古老的民间艺术焕发出新的生机与活力。",
    likes: 342,
    views: 2567,
    comments: 48
  }
};

const HeritageDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [selectedImage, setSelectedImage] = useState("");
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  
  useEffect(() => {
    const item = heritageDetails[id as keyof typeof heritageDetails];
    if (item) {
      setSelectedImage(item.image);
      setLikeCount(item.likes);
    }
  }, [id]);
  
  const item = heritageDetails[id as keyof typeof heritageDetails];
  
  if (!item) {
    return <div className="container mx-auto px-4 py-20 text-center text-gray-500">非遗项目不存在</div>;
  }
  
  const handleLike = () => {
    if (isLiked) {
      setLikeCount(prev => prev - 1);
    } else {
      setLikeCount(prev => prev + 1);
    }
    setIsLiked(!isLiked);
  };
  
  const handleShare = () => {
    // 实际项目中可以实现分享功能
    alert("分享功能已触发");
  };

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="container mx-auto px-4 py-24">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center text-gray-600 dark:text-gray-300 mb-8 hover:text-red-700 dark:hover:text-red-500 transition-colors"
      >
        <ChevronLeft size={20} className="mr-2" />
        返回
      </button>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* 图片展示区 */}
        <div className="lg:col-span-2">
          <motion.div 
            className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg mb-6"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
            transition={{ duration: 0.5 }}
          >
            <div className="h-[400px] overflow-hidden">
              <img 
                src={selectedImage} 
                alt={item.title} 
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-105" 
              />
            </div>
          </motion.div>
          
          {/* 图片画廊 */}
          <motion.div 
            className="grid grid-cols-3 gap-4"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {item.gallery.map((img, index) => (
              <div 
                key={index} 
                className={`cursor-pointer rounded-xl overflow-hidden shadow-md transition-all duration-300 ${
                  selectedImage === img ? 'ring-2 ring-red-700 dark:ring-red-500' : 'hover:ring-2 hover:ring-red-700 dark:hover:ring-red-500'
                }`}
                onClick={() => setSelectedImage(img)}
              >
                <img 
                  src={img} 
                  alt={`${item.title} - 图片${index + 1}`} 
                  className="w-full h-24 object-cover" 
                />
              </div>
            ))}
          </motion.div>
        </div>
        
        {/* 信息展示区 */}
        <motion.div 
          className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-lg"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <div className="mb-6">
            <span className="inline-block bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 text-sm px-3 py-1 rounded-full mb-4">
              {item.category}
            </span>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-4">{item.title}</h1>
            <div className="flex items-center text-gray-500 dark:text-gray-400 space-x-6 mb-6">
              <span className="flex items-center">
                <Eye size={18} className="mr-2" /> 
                {item.views} 次浏览
              </span>
              <span className="flex items-center">
                <MessageSquare size={18} className="mr-2" /> 
                {item.comments} 条评论
              </span>
            </div>
          </div>
          
          <div className="flex space-x-4 mb-8">
            <button 
              onClick={handleLike}
              className={`flex items-center justify-center px-6 py-3 rounded-full font-medium transition-all ${
                isLiked 
                  ? 'bg-red-700 text-white hover:bg-red-800' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              <Heart size={20} className={isLiked ? 'fill-white mr-2' : 'mr-2'} />
              {likeCount}
            </button>
            <button 
              onClick={handleShare}
              className="flex items-center justify-center px-6 py-3 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 font-medium transition-all"
            >
              <Share2 size={20} className="mr-2" />
              分享
            </button>
          </div>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-3">项目介绍</h3>
              <p className="text-gray-600 dark:text-gray-300">{item.description}</p>
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-3">历史渊源</h3>
              <p className="text-gray-600 dark:text-gray-300">{item.history}</p>
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-3">艺术特色</h3>
              <p className="text-gray-600 dark:text-gray-300">{item.characteristics}</p>
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-3">传承发展</h3>
              <p className="text-gray-600 dark:text-gray-300">{item.inheritance}</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default HeritageDetail;