import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, User, Eye, MessageSquare, Share2, ChevronLeft } from 'lucide-react';

// 模拟新闻详情数据
const newsDetails = {
  1: {
    id: 1,
    title: "辽宁省举办非遗文化艺术节",
    date: "2025-10-20",
    author: "辽宁非遗保护中心",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Cultural%20festival%20of%20intangible%20cultural%20heritage%2C%20traditional%20performances%2C%20crowd%20of%20people&sign=e313bac3b6365235ca07378e72c88af8",
    gallery: [
      "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Traditional%20Chinese%20music%20performance%20at%20cultural%20festival&sign=a86ae21755a9ef857f532fc456007f55",
      "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Traditional%20craft%20demonstration%2C%20artisan%20at%20work&sign=7d2f4c1e0bf115864bf4552c0300d4c6",
      "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Crowd%20enjoying%20cultural%20festival%20performances&sign=4b99da8686e44d95ea6c45ad7c46250b"
    ],
    content: [
      "10月18日至20日，辽宁省非遗文化艺术节在沈阳盛大举行。本次艺术节由辽宁省文化和旅游厅主办，辽宁省非物质文化遗产保护中心承办，以'传承非遗·共享美好'为主题，旨在展示辽宁地区丰富的非物质文化遗产资源，促进非遗的传承与发展。",
      
      "艺术节期间，来自全省各地的100多个非遗项目集中亮相，包括传统音乐、传统舞蹈、传统戏剧、传统美术、传统技艺等多个类别。活动现场设置了非遗展示区、互动体验区、传承人手作区等多个功能区域，吸引了数万名市民和游客前来参观体验。",
      
      "在非遗展示区，观众可以欣赏到辽宁剪纸、辽西皮影戏、满族刺绣、辽瓷烧制技艺等国家级、省级非遗项目的精彩展示。传承人们现场演示传统技艺，让观众近距离感受非遗的魅力。互动体验区则为观众提供了亲手制作非遗作品的机会，包括剪纸、陶艺、编织等项目，让大家在实践中体验传统工艺的乐趣。",
      
      "此外，艺术节还举办了非遗保护论坛、学术研讨会等活动，邀请了国内外专家学者就非遗保护与传承的理论和实践进行深入探讨，为辽宁非遗的保护和发展提供了新思路。",
      
      "据辽宁省文化和旅游厅相关负责人介绍，本次非遗文化艺术节是辽宁省推动非遗保护工作的重要举措，通过搭建展示、交流、传承的平台，让更多人了解和喜爱非遗，为非遗的活态传承创造良好的社会环境。未来，辽宁省将继续加大对非遗的保护力度，推动非遗融入现代生活，让这一宝贵的文化遗产焕发新的生机与活力。"
    ],
    views: 1256,
    comments: 32
  }
};

const NewsDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const newsItem = newsDetails[id as keyof typeof newsDetails];
  
  if (!newsItem) {
    return <div className="container mx-auto px-4 py-20 text-center text-gray-500">新闻不存在</div>;
  }
  
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="container mx-auto px-4 py-24">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center text-gray-600 dark:text-gray-300 mb-10 hover:text-red-700 dark:hover:text-red-500 transition-colors"
      >
        <ChevronLeft size={20} className="mr-2" />
        返回
      </button>
      
      <div className="max-w-3xl mx-auto">
        <motion.div 
          className="mb-10"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-6">{newsItem.title}</h1>
          
          <div className="flex flex-wrap items-center text-gray-500 dark:text-gray-400 space-x-6 mb-8">
            <span className="flex items-center">
              <Calendar size={18} className="mr-2" /> 
              {newsItem.date}
            </span>
            <span className="flex items-center">
              <User size={18} className="mr-2" /> 
              {newsItem.author}
            </span>
            <span className="flex items-center">
              <Eye size={18} className="mr-2" /> 
              {newsItem.views} 次浏览
            </span>
            <span className="flex items-center">
              <MessageSquare size={18} className="mr-2" /> 
              {newsItem.comments} 条评论
            </span>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg mb-10">
            <img 
              src={newsItem.image} 
              alt={newsItem.title} 
              className="w-full h-auto object-cover" 
            />
          </div>
        </motion.div>
        
        {/* 新闻内容 */}
        <motion.div 
          className="prose prose-lg dark:prose-invert max-w-none"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {newsItem.content.map((paragraph, index) => (
            <p key={index} className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
              {paragraph}
            </p>
          ))}
        </motion.div>
        
        {/* 图片画廊 */}
        <motion.div 
          className="mt-16"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">活动图集</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {newsItem.gallery.map((img, index) => (
              <div 
                key={index} 
                className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all duration-300"
              >
                <img 
                  src={img} 
                  alt={`${newsItem.title} - 图片${index + 1}`} 
                  className="w-full h-48 object-cover" 
                />
              </div>
            ))}
          </div>
        </motion.div>
        
        {/* 操作按钮 */}
        <motion.div 
          className="mt-12 flex justify-center"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <button 
            className="flex items-center justify-center px-8 py-3 rounded-full bg-red-700 text-white hover:bg-red-800 font-medium transition-all shadow-lg hover:shadow-xl"
          >
            <Share2 size={20} className="mr-2" />
            分享此新闻
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default NewsDetail;