import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, Calendar, Award, MessageSquare, Share2 } from 'lucide-react';

// 模拟传承人详情数据
const artistDetails = {
  1: {
    id: 1,
    name: "王淑兰",
    specialty: "辽宁剪纸传承人",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Elderly%20Chinese%20woman%2C%20paper%20cutting%20artist%2C%20traditional%20crafts%2C%20smiling&sign=5ba585eb6736c1841953ce281370fc9a",
    coverImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Elderly%20Chinese%20woman%20paper%20cutting%20artist%20at%20work%2C%20traditional%20craft%20workshop&sign=3b2f85b4c7c3c84b63adbbac1648b5cb",
    gallery: [
      "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Paper%20cutting%20artist%20teaching%20students%2C%20traditional%20craft%20education&sign=6534ff3900dfb867b4f939bebaa9598c",
      "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Collection%20of%20paper%20cutting%20artworks%2C%20various%20designs&sign=13ef4bed69741eb6ad803162c18eb17c",
      "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Paper%20cutting%20tools%20and%20materials%2C%20traditional%20craft&sign=116259cacd4573ef50357d178ebbaec9"
    ],
    birthYear: 1945,
    achievements: [
      "国家级非物质文化遗产项目代表性传承人",
      "辽宁省工艺美术大师",
      "中国民间文艺家协会会员"
    ],
    introduction: "王淑兰，1945年出生于辽宁省沈阳市，国家级非物质文化遗产项目（辽宁剪纸）代表性传承人。自幼跟随外祖母学习剪纸技艺，至今已有60余年的从艺经历。",
    experience: [
      "王淑兰的剪纸作品题材广泛，包括神话传说、历史故事、自然风光、花鸟鱼虫等，她的作品构图饱满、线条流畅、刀法精细，具有鲜明的地方特色和个人风格。",
      
      "在长期的艺术实践中，王淑兰不断创新剪纸技艺，将传统技法与现代审美相结合，创作出一批既有传统韵味又具时代特色的优秀作品。她的作品曾多次在国内外展览中获奖，并被多家博物馆收藏。",
      
      "作为非遗传承人，王淑兰十分重视剪纸艺术的传承与推广。多年来，她积极参与各类非遗展示活动，走进学校、社区、乡村，开展剪纸技艺培训和普及工作，培养了一大批剪纸爱好者和新一代传承人。",
      
      "王淑兰常说：'剪纸是我们民族文化的瑰宝，我有责任将这门技艺传承下去，让更多的人了解和喜爱剪纸艺术。'她用自己的实际行动诠释了非遗传承人的责任与担当。"
    ],
    quotes: "剪纸不仅是一门手艺，更是一种文化的传承。我希望通过我的努力，让更多的人了解剪纸、喜爱剪纸，让这一古老的民间艺术在新时代焕发出新的生机。",
    comments: 28
  }
};

const ArtistDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const artist = artistDetails[id as keyof typeof artistDetails];
  
  if (!artist) {
    return <div className="container mx-auto px-4 py-20 text-center text-gray-500">传承人信息不存在</div>;
  }
  
  // 计算年龄
  const calculateAge = (birthYear: number) => {
    const currentYear = new Date().getFullYear();
    return currentYear - birthYear;
  };
  
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="container mx-auto px-4 py-24">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center text-gray-600 dark:text-gray-300 mb-10 hover:text-red-700 dark:hover:text-red-500 transition-colors"
      >
        <ChevronLeft size={20} className="mr-2" />
        返回
      </button>
      
      {/* 封面和基本信息 */}
      <motion.div 
        className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden mb-16"
        initial="hidden"
        animate="visible"
        variants={fadeIn}
        transition={{ duration: 0.5 }}
      >
        <div className="relative h-64 md:h-96">
          <img 
            src={artist.coverImage} 
            alt={`${artist.name}的工作室`} 
            className="w-full h-full object-cover" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        </div>
        
        <div className="container mx-auto px-6 -mt-20 relative z-10">
          <div className="flex flex-col md:flex-row items-center md:items-start">
            <div className="w-32 h-32 md:w-48 md:h-48 rounded-full border-4 border-white dark:border-gray-800 overflow-hidden shadow-xl mb-6 md:mb-0 md:mr-8">
              <img 
                src={artist.image} 
                alt={artist.name} 
                className="w-full h-full object-cover" 
              />
            </div>
            
            <div className="text-center md:text-left">
              <h1 className="text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-2">{artist.name}</h1>
              <p className="text-xl text-red-700 dark:text-red-500 mb-4">{artist.specialty}</p>
              
              <div className="flex flex-wrap justify-center md:justify-start items-center space-x-6 text-gray-600 dark:text-gray-300">
                <span className="flex items-center">
                  <Calendar size={18} className="mr-2" /> 
                  {artist.birthYear}年生（{calculateAge(artist.birthYear)}岁）
                </span>
                <span className="flex items-center">
                  <MessageSquare size={18} className="mr-2" /> 
                  {artist.comments} 条评论
                </span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="container mx-auto px-6 py-10">
          <div className="flex flex-wrap gap-3 mb-8">
            {artist.achievements.map((achievement, index) => (
              <span 
                key={index} 
                className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 px-4 py-2 rounded-full text-sm font-medium"
              >
                {achievement}
              </span>
            ))}
          </div>
          
          {/* 引言 */}
          <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-xl mb-10">
            <p className="text-xl italic text-gray-700 dark:text-gray-300">"{artist.quotes}"</p>
            <p className="text-right font-medium text-gray-600 dark:text-gray-400 mt-4">— {artist.name}</p>
          </div>
          
          {/* 详细介绍 */}
          <div className="prose prose-lg dark:prose-invert max-w-none">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6 border-b border-gray-200 dark:border-gray-700 pb-3">艺术人生</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">{artist.introduction}</p>
            
            {artist.experience.map((paragraph, index) => (
              <p key={index} className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>
        </div>
      </motion.div>
      
      {/* 作品集 */}
      <motion.div 
        className="container mx-auto px-6 mb-16"
        initial="hidden"
        animate="visible"
        variants={fadeIn}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-8">代表作品与传承活动</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {artist.gallery.map((img, index) => (
            <div 
              key={index} 
              className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
            >
              <img 
                src={img} 
                alt={`${artist.name}的作品${index + 1}`} 
                className="w-full h-56 object-cover" 
              />
              <div className="p-4">
                <p className="text-gray-600 dark:text-gray-300">
                  {index === 0 ? "传授剪纸技艺" : index === 1 ? "部分代表作品" : "剪纸工具与材料"}
                </p>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
      
      {/* 操作按钮 */}
      <motion.div 
        className="container mx-auto px-6 flex justify-center"
        initial="hidden"
        animate="visible"
        variants={fadeIn}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        <button 
          className="flex items-center justify-center px-8 py-3 rounded-full bg-red-700 text-white hover:bg-red-800 font-medium transition-all shadow-lg hover:shadow-xl"
        >
          <Share2 size={20} className="mr-2" />
          分享传承人故事
        </button>
      </motion.div>
    </div>
  );
};

export default ArtistDetail;