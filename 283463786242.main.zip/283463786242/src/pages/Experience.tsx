import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Upload, Image as ImageIcon, RefreshCw, Download, ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const Experience = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [resultImage, setResultImage] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  
  // 模拟剪纸风格转换
  useEffect(() => {
    if (isProcessing && selectedFile) {
      // 模拟处理时间
      const timer = setTimeout(() => {
        // 实际项目中这里会调用AI处理接口
        // 这里使用模拟的结果图片
        setResultImage("https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Digital%20paper%20cutting%20art%20style%2C%20black%20and%20white%2C%20intricate%20patterns&sign=e49f90787cf1ab36ef1c3b8d9e5d4f41");
        setIsProcessing(false);
        toast.success("剪纸生成成功！");
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [isProcessing, selectedFile]);
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = () => {
    setIsDragging(false);
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };
  
  const handleFileSelect = (file: File) => {
    // 检查文件类型
    if (!file.type.match('image.*')) {
      toast.error("请上传图片文件");
      return;
    }
    
    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
    setResultImage("");
  };
  
  const handleUploadClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelect(e.target.files[0]);
    }
  };
  
  const startProcessing = () => {
    if (!selectedFile) {
      toast.error("请先上传图片");
      return;
    }
    
    setIsProcessing(true);
    toast.info("正在生成剪纸，请稍候...");
  };
  
  const handleDownload = () => {
    if (!resultImage) {
      toast.error("没有可下载的结果");
      return;
    }
    
    // 创建下载链接
    const link = document.createElement('a');
    link.href = resultImage;
    link.download = 'paper-cutting-artwork.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success("图片下载成功");
  };
  
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="container mx-auto px-4 py-24">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center text-gray-600 dark:text-gray-300 mb-10 hover:text-red-700 dark:hover:text-red-500 transition-colors"
      >
        <ChevronLeft size={20} className="mr-2" />
        返回
      </button>
      
      <motion.div 
        className="max-w-4xl mx-auto text-center mb-16"
        initial="hidden"
        animate="visible"
        variants={fadeIn}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-6">剪纸风格生成体验</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300">
          上传一张图片，我们将为您生成独特的剪纸风格作品，体验传统工艺与现代技术的完美融合。
        </p>
      </motion.div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 max-w-6xl mx-auto">
        {/* 上传区域 */}
        <motion.div 
          className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="p-8 border-b border-gray-100 dark:border-gray-700">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">上传图片</h2>
            <p className="text-gray-600 dark:text-gray-300 mt-2">支持 JPG、PNG、WEBP 格式，文件大小不超过 10MB</p>
          </div>
          
          <div 
            className={`p-10 flex flex-col items-center justify-center ${
              isDragging 
                ? 'bg-red-50 dark:bg-red-900/20 border-2 border-dashed border-red-700 dark:border-red-500' 
                : 'bg-gray-50 dark:bg-gray-700/50 border-2 border-dashed border-gray-300 dark:border-gray-600'
            } transition-all duration-300 cursor-pointer min-h-[300px]`}
            onClick={handleUploadClick}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            {previewUrl ? (
              <div className="relative w-full max-w-md">
                <img 
                  src={previewUrl} 
                  alt="预览图片" 
                  className="w-full h-auto rounded-lg object-cover" 
                />
                <button 
                  className="absolute top-2 right-2 w-8 h-8 bg-white dark:bg-gray-800 rounded-full flex items-center justify-center shadow-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedFile(null);
                    setPreviewUrl("");
                    setResultImage("");
                  }}
                >
                  <i className="fa-solid fa-times text-gray-500 dark:text-gray-400"></i>
                </button>
              </div>
            ) : (
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Upload size={32} className="text-red-700 dark:text-red-500" />
                </div>
                <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-2">
                  点击上传或拖拽图片到此处
                </h3>
                <p className="text-gray-500 dark:text-gray-400 mb-6">
                  或 <span className="text-red-700 dark:text-red-500 font-medium">浏览文件</span>
                </p>
                <input 
                  type="file" 
                  accept="image/*" 
                  ref={fileInputRef} 
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>
            )}
          </div>
          
          <div className="p-6 flex justify-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              className={`px-8 py-3 rounded-full font-medium transition-all ${
                selectedFile 
                  ? 'bg-red-700 text-white hover:bg-red-800 shadow-lg' 
                  : 'bg-gray-200 text-gray-500 cursor-not-allowed'
              }`}
              onClick={startProcessing}
              disabled={!selectedFile || isProcessing}
            >
              {isProcessing ? (
                <div className="flex items-center">
                  <RefreshCw size={18} className="mr-2 animate-spin" />
                  正在生成...
                </div>
              ) : (
                '开始生成剪纸'
              )}
            </motion.button>
          </div>
        </motion.div>
        
        {/* 结果展示区域 */}
        <motion.div 
          className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <div className="p-8 border-b border-gray-100 dark:border-gray-700">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">剪纸结果</h2>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              {resultImage 
                ? '您的剪纸作品已生成完成，点击下载保存' 
                : '上传图片并点击生成按钮，查看您的剪纸作品'}
            </p>
          </div>
          
          <div className="p-10 flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-700/50 min-h-[300px]">
            {resultImage ? (
              <div className="relative w-full max-w-md">
                <img 
                  src={resultImage} 
                  alt="剪纸结果" 
                  className="w-full h-auto rounded-lg object-cover" 
                />
              </div>
            ) : !isProcessing ? (
              <div className="text-center">
                <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ImageIcon size={32} className="text-gray-500 dark:text-gray-400" />
                </div>
                <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-2">
                  剪纸作品将在这里展示
                </h3>
                <p className="text-gray-500 dark:text-gray-400">
                  完成上传后，点击"开始生成剪纸"按钮
                </p>
              </div>
            ) : (
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                  <RefreshCw size={32} className="text-red-700 dark:text-red-500 animate-spin" />
                </div>
                <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-2">
                  正在为您生成剪纸
                </h3>
                <p className="text-gray-500 dark:text-gray-400">
                  这可能需要几秒钟的时间，请稍候...
                </p>
              </div>
            )}
          </div>
          
          <div className="p-6 flex justify-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              className={`px-8 py-3 rounded-full font-medium transition-all flex items-center ${
                resultImage 
                  ? 'bg-red-700 text-white hover:bg-red-800 shadow-lg' 
                  : 'bg-gray-200 text-gray-500 cursor-not-allowed'
              }`}
              onClick={handleDownload}
              disabled={!resultImage}
            >
              <Download size={18} className="mr-2" />
              下载剪纸作品
            </motion.button>
          </div>
        </motion.div>
      </div>
      
      {/* 剪纸艺术介绍 */}
      <motion.div 
        className="max-w-6xl mx-auto mt-20 bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-10"
        initial="hidden"
        animate="visible"
        variants={fadeIn}
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-6 text-center">剪纸艺术简介</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              剪纸是中国最古老的民间艺术之一，有着悠久的历史。辽宁剪纸作为中国剪纸的重要流派，以其独特的艺术风格和精湛的技艺著称于世。
            </p>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              传统剪纸通常使用红色纸张，通过剪刀或刻刀在纸上剪出各种图案，包括人物、花鸟、虫鱼、神话传说等，常用于装饰和祈福。
            </p>
            <p className="text-gray-600 dark:text-gray-300">如今，随着数字技术的发展，我们可以利用现代科技手段将普通图片转换为剪纸风格，让更多人感受到这一传统艺术的魅力。
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img 
              src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Traditional%20Chinese%20paper%20cutting%20art%2C%20red%20paper%2C%20flower%20pattern&sign=3cb1a2720085acf9bc4265b57d816604" 
              alt="剪纸艺术1" 
              className="rounded-lg shadow-md hover:shadow-lg transition-all duration-300" 
            />
            <img 
              src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Traditional%20Chinese%20paper%20cutting%20art%2C%20red%20paper%2C%20animal%20pattern&sign=7a0e82c3bde021e837ac363d8a422e34" 
              alt="剪纸艺术2" 
              className="rounded-lg shadow-md hover:shadow-lg transition-all duration-300 mt-6" 
            />
            <img 
              src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Traditional%20Chinese%20paper%20cutting%20art%2C%20red%20paper%2C%20dragon%20pattern&sign=ebdc2610402acff08e012de38655bed4" 
              alt="剪纸艺术3" 
              className="rounded-lg shadow-md hover:shadow-lg transition-all duration-300 mt-6" 
            />
            <img 
              src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Traditional%20Chinese%20paper%20cutting%20art%2C%20red%20paper%2C%20landscape%20pattern&sign=bf1ee6c71eafac0c8f28a7dbf8d14a82" 
              alt="剪纸艺术4" 
              className="rounded-lg shadow-md hover:shadow-lg transition-all duration-300" 
            />
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Experience;