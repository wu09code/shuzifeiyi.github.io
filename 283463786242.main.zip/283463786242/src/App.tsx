import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import HeritageDetail from "@/pages/HeritageDetail";
import Experience from "@/pages/Experience";
import NewsDetail from "@/pages/NewsDetail";
import ArtistDetail from "@/pages/ArtistDetail";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function App() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-amber-50 to-white dark:from-gray-900 dark:to-gray-800">
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/heritage/:id" element={<HeritageDetail />} />
          <Route path="/experience" element={<Experience />} />
          <Route path="/news/:id" element={<NewsDetail />} />
          <Route path="/artist/:id" element={<ArtistDetail />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
