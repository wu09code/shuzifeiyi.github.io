# 数字非遗 - 传统文化与现代科技的融合

一个将传统非物质文化遗产通过现代科技手段进行数字化、传承和创新的Web应用。

## 📚 项目介绍

"数字非遗"网站旨在通过AI技术将用户上传的图片或文字描述转化为具有传统艺术风格（如剪纸、苏绣、皮影等）的艺术作品，让古老的非遗文化在数字时代焕发新生。

## ✨ 功能特点

- **图片转化功能**：将用户上传的图片转化为剪纸、苏绣、皮影等风格的艺术作品
- **文字描述转化**：根据用户输入的文字描述生成相应风格的图案
- **多种风格选择**：提供剪纸、苏绣、皮影、水墨画等多种传统艺术风格
- **实时预览**：上传图片或输入文字后，实时预览转换结果
- **作品下载与分享**：支持下载生成的作品或分享到社交平台
- **非遗知识展示**：提供传统艺术的历史、技巧和文化背景介绍
- **深色/浅色模式切换**：支持用户根据偏好切换界面主题

## 🛠 技术栈

- **前端框架**：React 18+
- **编程语言**：TypeScript
- **构建工具**：Vite
- **样式处理**：Tailwind CSS
- **状态管理**：React Context API
- **动画效果**：Framer Motion
- **图标库**：Lucide React
- **路由管理**：React Router DOM
- **弹窗提示**：Sonner

## 🚀 快速开始

### 环境要求

- Node.js 18+
- PNPM (推荐) 或 NPM/Yarn

### 安装依赖

```bash
# 使用PNPM（推荐）
pnpm install

# 或使用NPM
npm install

# 或使用Yarn
yarn install
```

### 开发模式

```bash
# 使用PNPM（推荐）
pnpm dev

# 或使用NPM
npm run dev

# 或使用Yarn
yarn dev
```

项目将在 http://localhost:3000 启动开发服务器

### 构建项目

```bash
# 使用PNPM（推荐）
pnpm build

# 或使用NPM
npm run build

# 或使用Yarn
yarn build
```

构建后的文件将位于 `dist` 目录

### 预览构建结果

```bash
# 使用PNPM（推荐）
pnpm preview

# 或使用NPM
npm run preview

# 或使用Yarn
yarn preview
```

## 📦 项目发布

### 1. 本地构建测试

首先确保项目能在本地正常构建：

```bash
pnpm build
pnpm preview
```

检查预览是否正常，确保所有功能都能正常工作。

### 2. 选择部署平台

这个项目是纯静态网站，可以部署到多种平台：

- **GitHub Pages**
- **Vercel**
- **Netlify**
- **Firebase Hosting**
- **阿里云OSS/腾讯云COS**
- 或任何支持静态网站托管的平台

### 3. 部署到GitHub Pages

1. 确保你有一个GitHub仓库
2. 安装 `gh-pages` 包：
   ```bash
   pnpm add -D gh-pages
   ```
3. 在package.json中添加脚本：
   ```json
   "scripts": {
     "deploy": "gh-pages -d dist/static"
   }
   ```
4. 运行部署命令：
   ```bash
   pnpm build
   pnpm deploy
   ```

### 4. 部署到Vercel/Netlify

1. 注册Vercel或Netlify账号
2. 连接你的GitHub仓库
3. 配置构建设置：
   - 构建命令：`pnpm build`
   - 发布目录：`dist/static`
4. 点击部署按钮

### 5. 自定义域名配置

如果需要使用自定义域名，可以在部署平台的设置中进行配置，通常需要：

1. 在域名注册商处添加DNS记录
2. 在部署平台上配置域名绑定

## 📁 项目结构

```
├── src/                 # 源代码目录
│   ├── components/      # 可复用组件
│   ├── contexts/        # React Context
│   ├── hooks/           # 自定义Hooks
│   ├── lib/             # 工具函数
│   ├── pages/           # 页面组件
│   ├── App.tsx          # 应用入口组件
│   ├── index.css        # 全局样式
│   └── main.tsx         # 应用渲染入口
├── index.html           # HTML模板
├── package.json         # 项目配置和依赖
├── tailwind.config.js   # Tailwind CSS配置
└── vite.config.ts       # Vite配置
```

## 🎨 设计理念

网站设计融合了现代科技感与传统元素：

- **色彩方案**：使用蓝色、紫色等科技感色调为主，搭配传统非遗元素的红色、金色等
- **排版**：采用清晰的层级结构，突出重要内容
- **动效**：添加流畅的过渡动画和微交互，提升用户体验
- **响应式**：完全响应式设计，适配各种设备尺寸

## 🔮 未来规划

- [ ] 用户账户系统和作品保存功能
- [ ] 更多非遗艺术风格的支持
- [ ] 社区互动功能增强
- [ ] 移动端应用开发
- [ ] 商业授权和高分辨率下载功能

## 🤝 贡献指南

欢迎对项目进行贡献！如果你有任何建议或发现问题，请提交Issue或Pull Request。

## 📝 许可证

本项目采用MIT许可证。