# 数字非遗 - 传统文化与现代科技的融合

一个将现代科技与传统非物质文化遗产相结合的Web应用，通过AI技术将用户上传的图片或文字描述转化为具有传统艺术风格（如剪纸、苏绣、皮影等）的艺术作品。

## 项目特性

- **图片转化功能**：将普通图片转化为剪纸、苏绣、皮影等非遗艺术风格
- **文字描述转化**：根据文字描述生成相应的非遗艺术作品
- **多种风格选择**：提供多种传统艺术风格供用户选择
- **实时预览与下载**：实时预览转化效果并下载作品
- **响应式设计**：支持桌面和移动设备
- **深色/浅色模式**：支持主题切换

## 技术栈

- React 18+
- TypeScript
- Vite
- Tailwind CSS
- Framer Motion (动画效果)
- React Router (路由)
- Lucide React (图标)

## 快速开始

### 前置要求

确保您已安装以下软件：
- Node.js (v16或更高版本)
- pnpm (推荐) 或 npm/yarn

### 安装依赖

```bash
# 使用pnpm (推荐)
pnpm install

# 或使用npm
npm install

# 或使用yarn
yarn install
```

### 运行开发服务器

```bash
# 使用pnpm
pnpm dev

# 或使用npm
npm run dev

# 或使用yarn
yarn dev
```

开发服务器启动后，打开浏览器访问 http://localhost:3000 查看应用。

### 构建生产版本

```bash
# 使用pnpm
pnpm build

# 或使用npm
npm run build

# 或使用yarn
yarn build
```

构建完成后，生产版本的文件将生成在 `dist` 目录中。

### 预览生产版本

构建完成后，您可以使用以下命令预览生产版本：

```bash
# 使用Vite的预览功能
npx vite preview

# 或使用其他静态文件服务器，如serve
npx serve dist
```

## 常见问题

### 1. 直接打开HTML文件显示空白

**问题原因**：
React应用需要通过服务器环境运行，而不是直接双击打开HTML文件（使用file://协议）。这是因为现代前端框架使用客户端路由和ES模块，这些特性在直接打开HTML文件时无法正常工作。

**解决方案**：
- 使用开发服务器运行项目：执行 `pnpm dev` 或 `npm run dev`
- 构建生产版本后使用静态文件服务器：执行 `pnpm build` 后，使用 `npx serve dist` 预览
- 不要直接双击 `index.html` 文件打开

### 2. 图片显示问题

**问题原因**：
图片路径可能不正确或图片资源无法访问。

**解决方案**：
- 确保图片URL正确
- 检查网络连接
- 等待图片加载完成

### 3. 主题切换不工作

**问题原因**：
本地存储可能被禁用或出现问题。

**解决方案**：
- 确保浏览器允许本地存储
- 尝试清除浏览器缓存

## 部署指南

### 使用Netlify部署

1. 在Netlify上创建账户
2. 连接您的Git仓库
3. 配置构建命令：`pnpm build`
4. 配置发布目录：`dist`
5. 点击"部署站点"

### 使用Vercel部署

1. 在Vercel上创建账户
2. 导入您的Git仓库
3. Vercel会自动检测项目配置
4. 点击"部署"

### 使用GitHub Pages部署

1. 构建项目：`pnpm build`
2. 安装gh-pages：`pnpm add -D gh-pages`
3. 添加部署脚本到package.json：
   ```json
   "scripts": {
     "deploy": "gh-pages -d dist"
   }
   ```
4. 执行部署：`pnpm deploy`

## 联系我们

如有任何问题或建议，请联系我们：contact@digitalheritage.com